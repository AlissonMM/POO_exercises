package lista10;

public class Administracao {

	public static void main(String[] args) {
		Populacao populacao = new Populacao(2,2);
		
		populacao.atualizarPopulacao(1, 0, 2);
		populacao.atualizarPopulacao(1, 1, 10);
		
		populacao.atualizarPopulacao(0, 0, 3);
		populacao.atualizarPopulacao(0, 1, 5);
		
		populacao.mediaPopulacao(1);
		populacao.mediaPopulacao(0);

	}

}
