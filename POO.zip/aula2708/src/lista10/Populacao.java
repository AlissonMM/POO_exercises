package lista10;

public class Populacao {
	private int pop [][];
	public int estados, municipios;
	
	public Populacao(int estados, int municipios) {

		this.pop = new int[estados][municipios];
		this.estados = estados;
		this.municipios = municipios;
	}
	
	public void atualizarPopulacao(int i, int j, int populacao) {
		if(i>=0 && i<4 && j>=0 && j<5 && populacao >0) {
			pop[i][j] = populacao;
		}
	}
	
	public void mediaPopulacao(int estado) {
		float soma = 0;
		int contador = 0;
		for (int i = 0; i < this.municipios; i++) {
			soma += pop[estado][i];
			contador++;
		}
		
		float media = soma / contador;
		
		System.out.println("Media do estado " + estado + " e " +media);
	}
	
	
}
