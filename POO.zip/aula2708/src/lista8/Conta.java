package lista8;

public class Conta {
	private double saldo;
	private String nrAgencia;
	private String titular;
	private int nrConta;
	private int codBanco;
	
	public Conta(double saldo, String nrAgencia, String titular, int nrConta, int codBanco) {
		super();
		this.saldo = saldo;
		this.nrAgencia = nrAgencia;
		this.titular = titular;
		this.nrConta = nrConta;
		this.codBanco = codBanco;
	}
	
	public void saque(double valor) {
		if(valor > 0) {
			if(saldo >= valor) {
				System.out.println("Sacou " + valor);
				saldo = saldo - valor;
			}
			else {
				System.out.println("Saldo insuficiente");
			}
		}
		return;
	}

	public double getSaldo() {
		return saldo;
	}

	public String getNrAgencia() {
		return nrAgencia;
	}

	public String getTitular() {
		return titular;
	}

	public int getNrConta() {
		return nrConta;
	}

	public int getCodBanco() {
		return codBanco;
	}
	
	public void deposito(double valor) {
		if(valor > 0) {
			saldo += valor;
		}
		
		
	
	
	
	}
	
	public void imprimeDados() {
		System.out.println("\n-------------------");
		System.out.println("AGENCIA:\t"+nrConta);
		System.out.println("TITULAR:\t"+titular);
		System.out.println("SALDO:\t        "+saldo);
		System.out.println("--------------------");
	
}
}
