package lista8;

public class TestaConta {

	public static void main(String[] args) {
		
		 Conta conta = new Conta(1000, "01", "Baor", 01, 01);
		 
		 conta.saque(1000);
		 
		 System.out.println(conta.getSaldo());
		 
		 conta.deposito(2000);
		 System.out.println(conta.getSaldo());
		 
		 conta.imprimeDados();

	}

}
