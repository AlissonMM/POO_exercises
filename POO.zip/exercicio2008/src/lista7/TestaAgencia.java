package lista7;

public class TestaAgencia {

	public static void main(String[] args) {
		Agencia agencia = new Agencia();
		
		agencia.setnAgencia("24");
		
		agencia.setCodBanco(69);
		
		agencia.Imprimir();
		

	}

}
