package lista7;

public class Agencia {
	private String nAgencia;
	private int codBanco;
	public String getnAgencia() {
		return nAgencia;
	}
	public void setnAgencia(String nAgencia) {
		this.nAgencia = nAgencia;
	}
	public int getCodBanco() {
		return codBanco;
	}
	public void setCodBanco(int codBanco) {
		this.codBanco = codBanco;
	}
	
	
	public void Imprimir() {
		System.out.println(
				"*-----------------\n"+
		"*AGENCIA: " + nAgencia +
		"\n BANCO: " + codBanco +
		"\n*-----------------");
	}
	
	
	

}
