package exercicio1;

public class Principal {

	public static void main(String[] args) {
		Computador computer = new Computador("HP", "Branco", "Nova geracao", "2", 2000f);
		
		System.out.println(computer.imprimirDados());
		

	}

}
