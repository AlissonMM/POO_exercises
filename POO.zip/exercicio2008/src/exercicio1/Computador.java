package exercicio1;

public class Computador {
	private String marca;
	private String cor;
	private String modelo;
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	private String serie;
	private Float valor;
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getSerie() {
		return serie;
	}
	public void setSerie(String serie) {
		this.serie = serie;
	}
	public Float getValor() {
		return valor;
	}
	public void setValor(Float valor) {
		this.valor = valor;
	}
	
	
	
	public Computador(String marca, String cor, String modelo, String serie, Float valor) {
		this.marca = marca;
		this.cor = cor;
		this.modelo = modelo;
		this.serie = serie;
		this.valor = valor;
	}
	
	public String imprimirDados() {
		String retornar = "Cor: " + this.cor + " Marca: " + this.marca + " Modelo: " + this.modelo  + " Serie: " + this.serie +  " Valor: " + this.valor;
		return retornar;
	}


}
