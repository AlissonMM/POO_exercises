package exercicio3;

public class UsaLampada {

	public static void main(String[] args) {
		Lampada lamp1 = new Lampada();
		Lampada lamp2 = new Lampada();

		lamp1.Ligar();
		lamp2.Desligar();
		
		System.out.println(lamp1.Observar());
		System.out.println(lamp2.Observar());
	}

}
