package exercicio3;

public class Lampada {
	private boolean status = false;
	
	public void Ligar() {
		this.status = true;
	}
	
	public void Desligar() {
		this.status = false;
	}
	
	public String Observar() {
		return this.status ? "Ligada" : "Desligada";
	}

}
