package exercicio2;

public class Eleitoral {

	private int idade;
	private String nome;
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		idade = idade;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Eleitoral(int Idade, String nome) {
		this.idade = Idade;
		this.nome = nome;
	}
	
	public void Imprimir() {
		System.out.println("Nome: " +this.nome + "\n Idade:" + this.idade);
		this.Verificar();
		
	}
	
	public void Verificar() {
		if (this.idade < 16) {
			System.out.println("O eleitor não pode votar");
		}
		
		else if (this.idade >= 16 && this.idade <= 65) {
			System.out.println("O eleitor deve votar!");
		}
		
		else if (this.idade > 65) {
			System.out.println("Voto Facultativo");
		}
	}
	
	
}
