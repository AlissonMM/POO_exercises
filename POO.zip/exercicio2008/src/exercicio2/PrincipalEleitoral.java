package exercicio2;

public class PrincipalEleitoral {

	public static void main(String[] args) {
		Eleitoral el = new Eleitoral(15, "Alisson");
		Eleitoral el2 = new Eleitoral(69, "Barsani");
		Eleitoral el3 = new Eleitoral(24, "Bruno");
		
		
		el.Imprimir();
		el2.Imprimir();
		el3.Imprimir();

	}

}
