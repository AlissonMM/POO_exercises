package exercicio2;

public class Roupa {
	private float kgRoupa;
	private boolean limpa;
	
	public Roupa(float kgRoupa) {
		this.kgRoupa = kgRoupa;
		limpa = true;
	}

	public float getKgRoupa() {
		return kgRoupa;
	}

	public void setKgRoupa(float kgRoupa) {
		this.kgRoupa = kgRoupa;
	}
	
	public void suja() {
		this.limpa = false;
	}
	
	public void limpa() {
		this.limpa = true;
	}
	
	public void status() {
		System.out.println("------------------------------------");
		System.out.println("Peso da roupa: " + kgRoupa);
		if(limpa) {
			System.out.println("Estado: Limpa");	
		}
		else {
			System.out.println("Estado: Suja");
		}
		
		System.out.println("------------------------------------\n");
	}
	
	
}
