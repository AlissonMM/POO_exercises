package exercicio2;

public class TestaRoupa {

	public static void main(String[] args) {
		Roupa camisa = new Roupa(0.1f);
		Roupa calca = new Roupa(1f);
		
		camisa.suja();
		calca.limpa();
		
		camisa.status();
		calca.status();

	}

}
