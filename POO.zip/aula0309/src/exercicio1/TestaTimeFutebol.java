package exercicio1;

public class TestaTimeFutebol {

	public static void main(String[] args) {
		TimeFutebol freljord = new TimeFutebol("Freljord", 0);
		TimeFutebol noxus = new TimeFutebol("Noxus", 1);
		TimeFutebol shadowIsle = new TimeFutebol("Shi", 1);
		
		freljord.venceu();
		noxus.empatou();
		shadowIsle.derrota();
		
		freljord.situacaoTime();
		noxus.situacaoTime();
		shadowIsle.situacaoTime();
		

	}

}
