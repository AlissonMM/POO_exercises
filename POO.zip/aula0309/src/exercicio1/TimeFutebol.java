package exercicio1;

public class TimeFutebol {
	private String nomeTime;
	private int qntJogados;
	private int jogosGanhos;
	//0 - retranqueiro, 1 - ataque
	private int retranqueiro;
	
	
	public TimeFutebol(String nomeTime, int retranqueiro) {
		super();
		this.nomeTime = nomeTime;
		this.retranqueiro = retranqueiro;
		qntJogados = 0;
		
		jogosGanhos = 0;
	}


	public String getRetranqueiro() {
		if (retranqueiro == 0) {
			return "Retranqueiro";
		}
		return "Atacante";
	}
	
	public void venceu() {
		jogosGanhos += 3;
		qntJogados += 1;
	}
	
	public void empatou() {
		jogosGanhos += 1;
		qntJogados += 1;
	}
	
	public void derrota() {
		jogosGanhos += 0;
		qntJogados += 1;
	}
	
	public void situacaoTime() {
		System.out.println("------------------------------------");
		System.out.println(nomeTime);
		System.out.println("\nPartidas jogadas: " + qntJogados);
		System.out.println("\nPontuacao: " + jogosGanhos);
		System.out.println("\nEstilo de jogo: " + this.getRetranqueiro());
		System.out.println("------------------------------------\n");
	}
	
	
	
	
}
