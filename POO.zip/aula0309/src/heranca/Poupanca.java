package heranca;

public class Poupanca extends Conta{
	
}
