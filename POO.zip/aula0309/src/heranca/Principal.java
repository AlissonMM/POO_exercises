package heranca;

public class Principal {

	public static void main(String[] args) {
		Conta c = new Conta();
		c.setTitular("Luis");
		System.out.println(c.getTitular());
		
		Corrente cc = new Corrente(1, "Agencia2", "Alisson", 2000, 100);
		System.out.println(cc.getTitular());
		System.out.println(cc.getNomeAgencia());
		System.out.println(cc.getSaldo());

	}

}
