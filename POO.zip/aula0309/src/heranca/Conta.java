package heranca;

public class Conta {
	private int codBanco;
	private String nomeAgencia;
	private String titular;
	
	public Conta(String nomeAgencia, String titular) {
		this.nomeAgencia = nomeAgencia;
		this.titular = titular;
	}

	public Conta() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Conta(int codBanco, String nomeAgencia, String titular) {
		this.codBanco = codBanco;
		this.nomeAgencia = nomeAgencia;
		this.titular = titular;
	}

	public int getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(int codBanco) {
		this.codBanco = codBanco;
	}

	public String getNomeAgencia() {
		return nomeAgencia;
	}

	public void setNomeAgencia(String nomeAgencia) {
		this.nomeAgencia = nomeAgencia;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}
	
	
}
