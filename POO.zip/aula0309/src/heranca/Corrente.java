package heranca;

public class Corrente extends Conta {
	
	private double saldo;
	private double limite;
	
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public double getLimite() {
		return limite;
	}
	public void setLimite(double limite) {
		this.limite = limite;
	}
	
	public Corrente() {
		
	}
	
	public Corrente(int codBanco, String nomeAgencia, String titular, double saldo, double limite) {
		super(codBanco, nomeAgencia, titular);
		this.saldo = saldo;
		this.limite = limite;
	}
	
	
	
	
	
	
}
