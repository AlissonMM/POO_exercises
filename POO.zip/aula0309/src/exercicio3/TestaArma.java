package exercicio3;

public class TestaArma {
	public static void main(String[] args) {
		Arma espada = new Arma("E");
		Arma arco = new Arma("A");
		Arma lanca = new Arma("L");
		
		espada.imprimir();
		arco.imprimir();
		lanca.setTipo("E");
		lanca.imprimir();
		
	}
	
	
	
}
