package exercicio3;

public class Arma {
	private String tipo;
	private int forca;
	
	public Arma(String tipo) {
		this.tipo = tipo.toUpperCase();
		
		if(this.tipo == "L") {
			forca = 4;
		}
		else if (this.tipo == "E") {
			forca = 5;
		}
		else if (this.tipo == "A") {
			forca = 3;
		}
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
		
		if(this.tipo == "L") {
			forca = 4;
		}
		else if (this.tipo == "E") {
			forca = 5;
		}
		else if (this.tipo == "A") {
			forca = 3;
		}
	}

	public int getForca() {
		return forca;
	}

	public void setForca(int forca) {
		this.forca = forca;
	}
	
	public void imprimir() {
		System.out.println("------------------------------------");
		if(this.tipo == "L") {
			System.out.println("Lanca");
		}
		else if (this.tipo == "E") {
			System.out.println("Espada");
		}
		else if (this.tipo == "A") {
			System.out.println("Arco");
		}
		
		System.out.println("Forca de destruicao: " + forca);

		System.out.println("------------------------------------\n");
	}
	
	
}
