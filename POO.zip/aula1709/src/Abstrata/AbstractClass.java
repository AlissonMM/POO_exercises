package Abstrata;

public abstract class AbstractClass {
	//metodos concretos
	public void calcularINSS() {
		System.out.println("Seu valor é 1 real");
	}
	//metodos abstratos
	public abstract void calcularMedia();
}
