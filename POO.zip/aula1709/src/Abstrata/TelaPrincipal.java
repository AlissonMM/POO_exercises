package Abstrata;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.TextArea;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField txtNome;
	private JButton btnLimpar;
	private TextArea txtResultado;
	private JLabel lblNewLabel_1;
	private JComboBox cmbEstado;
	private JButton btnMostrar;
	private JButton btnSair;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 605, 459);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Nome do Aluno");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel.setBounds(51, 50, 151, 44);
		contentPane.add(lblNewLabel);
		
		txtNome = new JTextField();
		txtNome.setBounds(239, 55, 136, 44);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtNome.setText(null);
				txtResultado.setText(null);
				cmbEstado.setSelectedIndex(0);

			}
		});
		btnLimpar.setBounds(235, 179, 89, 23);
		contentPane.add(btnLimpar);
		
		txtResultado = new TextArea();
		txtResultado.setBounds(101, 228, 380, 160);
		contentPane.add(txtResultado);
		
		lblNewLabel_1 = new JLabel("Estado Civil");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(51, 107, 151, 44);
		contentPane.add(lblNewLabel_1);
		
		cmbEstado = new JComboBox();
		cmbEstado.setToolTipText("Selecione uma opção");
		cmbEstado.setModel(new DefaultComboBoxModel(new String[] {"Selecione uma opção", "Casado", "Solteiro", "Desempregado", "Lascado"}));
		cmbEstado.setBounds(239, 110, 136, 44);
		contentPane.add(cmbEstado);
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtResultado.append(txtNome.getText());
				txtResultado.append(cmbEstado.getSelectedIndex().toString());
			}
		});
		btnMostrar.setBounds(75, 179, 89, 23);
		contentPane.add(btnMostrar);
		
		btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnSair.setBounds(417, 179, 89, 23);
		contentPane.add(btnSair);
	}
}
