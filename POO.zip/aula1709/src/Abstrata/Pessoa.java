package Abstrata;

public class Pessoa extends AbstractClass{
	
	public void calcularMedia() {
		System.out.println("bosta");
	}

}
