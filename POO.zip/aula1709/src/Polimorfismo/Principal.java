package Polimorfismo;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Juridica j = new Juridica("Fatec",13,"23434");
		System.out.println("Nome: " + j.getNome());
		j.imprimirDados();
	}

}
