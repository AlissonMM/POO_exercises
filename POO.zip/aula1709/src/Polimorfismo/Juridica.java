package Polimorfismo;

public class Juridica extends Pessoa{
	private String cnpj;
	
	public Juridica() {
		
	}

	public Juridica(String nome, int idade, String cnpj) {
		super(nome, idade);
		this.cnpj = cnpj;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
	@Override
	public void calcular() {
		System.out.println(10 + 3);
	}
	
	@Override
	public void imprimirDados() {
		super.imprimirDados();
		System.out.println("CNPJ: " + cnpj);
	}
	
	
}
