package Polimorfismo;

//Javabean

public class Pessoa implements IContrato{
	@Override
	public void calcularINSS() {
		// TODO Auto-generated method stub
		
	}

	private String nome;
	private int idade;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public Pessoa(String nome, int idade) {
		super();
		this.nome = nome;
		this.idade = idade;
	}
	
	public Pessoa() {
		
	}
	
	public void calcular() {
		System.out.println(10 * 3);
	}
	
	public void imprimirDados() {
		System.out.println("Nome: " + nome);
		System.out.println("Idade: " + idade);
	}
}
