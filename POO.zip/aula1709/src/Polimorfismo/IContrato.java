package Polimorfismo;

public interface IContrato {
	public void calcularINSS();
}
