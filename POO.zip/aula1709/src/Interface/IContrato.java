package Interface;

public interface IContrato {
	public void calcularINSS();
}
