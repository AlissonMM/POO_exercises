package aula1009;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Tela1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField textNome;
	private JLabel lblEmail;
	private JTextField textEmail;
	private JButton btnMostrar;
	private JButton btnSair;
	private TextArea textResultado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela1 frame = new Tela1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tela1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 687, 511);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Nome: ");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 27));
		lblNewLabel.setBounds(68, 29, 115, 55);
		contentPane.add(lblNewLabel);
		
		textNome = new JTextField();
		textNome.setBounds(198, 46, 169, 34);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		lblEmail = new JLabel("Email:");
		lblEmail.setForeground(Color.RED);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 27));
		lblEmail.setBounds(68, 107, 115, 55);
		contentPane.add(lblEmail);
		
		textEmail = new JTextField();
		textEmail.setColumns(10);
		textEmail.setBounds(198, 124, 169, 34);
		contentPane.add(textEmail);
		
		btnMostrar = new JButton("MOSTRAR");
		btnMostrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textResultado.append("NOME.........:"+textNome.getText());
				textResultado.append("\nEMAIL.........:"+textEmail.getText());
			}
		});
		btnMostrar.setForeground(new Color(255, 255, 255));
		btnMostrar.setBackground(new Color(0, 128, 255));
		btnMostrar.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnMostrar.setBounds(114, 214, 190, 86);
		contentPane.add(btnMostrar);
		
		btnSair = new JButton("SAIR");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnSair.setForeground(new Color(255, 255, 255));
		btnSair.setBackground(new Color(0, 128, 255));
		btnSair.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnSair.setBounds(355, 214, 190, 86);
		contentPane.add(btnSair);
		
		textResultado = new TextArea();
		textResultado.setBounds(114, 318, 443, 144);
		contentPane.add(textResultado);
	}
}
