package aula1308;

import java.util.ArrayList;
import java.util.List;

public class App1 {

	public static void main(String[] args) {
		
		//💩POO💩
		
		int v[] = {1,2,3,4,5,6,7,8,9,10};
		
		
		for(int a : v) {
			System.out.println(a + " ");
		}
		
		List<String> lista = new ArrayList();
		
		lista.add("Maca");
		lista.add("Banana");
		lista.add("Uva");
		
		
		for(String a : lista) {
			System.out.println(a);
		}

	}

}
