package test;

import aula1308.Pessoa;

public class Main {

	

	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa("Alisson", 19, "Rua fatec", "23", "NA");
		
		System.out.println(pessoa);
		
		

	}

}
