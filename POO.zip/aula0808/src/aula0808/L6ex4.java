package aula0808;

public class L6ex4 {

	public static void main(String[] args) {
		
		int[] vet = {5, 10, 8, 4, 9, 16, 28, 40, 80, 10};
		
		int soma = 0;
		
		for(int i = 0; i < 10; i++) {
			soma += vet[i];
		}
		
		System.out.println("O valor da soma eh: " + soma);
	}
}
