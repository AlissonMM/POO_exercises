package aula0808;

public class L6ex5 {

	public static void main(String[] args) {

		double[] vet = {85.0, 105.0, 40.0, 90.0, 35.0, 65.0, 33.0, 22.0, 19.0, 50.0};
		
		double soma = 0;
		
		for(int i = 0; i < 10; i++) {
			soma += vet[i];
		}
		
		System.out.println("O valor da media eh: " + soma/vet.length);
	}

}
