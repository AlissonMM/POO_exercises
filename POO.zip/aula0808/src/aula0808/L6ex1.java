package aula0808;

import java.util.*;

public class L6ex1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] vet = new int[20];
		int contador = 0;
		
		for(int i = 0; i < 20; i++) {
			System.out.println("Digite um valor: ");
			vet[i] = sc.nextInt();
		}
		
		for(int i = 0; i < 20; i++) {
			if(vet[i]%2==0) {
				contador++;
			}	
		}
		
		System.out.println("A quantidade de multiplos de 2 eh de: " + contador);
	}
}
