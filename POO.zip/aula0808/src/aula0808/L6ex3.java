package aula0808;

public class L6ex3 {

	public static void main(String[] args) {
		
		int[] vet = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		
		for(int i = 0; i < vet.length; i++) {
			System.out.println(vet[i]);
		}
	}
}
