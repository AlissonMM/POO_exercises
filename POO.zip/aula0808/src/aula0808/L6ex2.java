package aula0808;

import java.util.*;

public class L6ex2 {
	
	public static void main(String[] args) {
		
		int[] vet = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		
		for(int i = 0; i < vet.length; i++) {
			System.out.println(vet[i] + " - " + vet[9-i]);
		}
		
		//Solução teste que não deu certo
		/*for(int i = 0; i < 10; i++) {
			System.out.println(vet[i]);
		}
		
		for(int i = 9; i >= 0; i--) {
			System.out.println(vet[i]);
		}*/
		
	}
}
